# ------------------------------------------------------------------------ #
# Title: Assignment 07
# Description: Demonstrating pickling and error handling.
# ChangeLog (Who,When,What):
# GBooth,3.1.2023,Created script.
# ------------------------------------------------------------------------ #
import pickle

try:
    txtFile = open("PickleTest.txt", "r")
    p = pickle.load(txtFile)
    print(p)
    txtFile.close()
except Exception as e:
    print(e)
    print("***Problem loading due to not being in read-binary mode. Please use 'rb' when reading from a pickled file.***\n")
except UnicodeDecodeError:
    print("***Problem loading due to not being in read-binary mode. Please use 'rb' when reading from a pickled file.***\n")

def dataEntryPickle():
    fileInfo = "***This is information stored with pickling.***"
    txtFile = open("PickleTest.txt", "wb")
    pickle.dump(fileInfo, txtFile)
    txtFile.close()
    print(fileInfo + "\nData above was stored within a txt file. Open the file to verify contents is not readable.")

def readPickleError():
    txtFile = open("PickleTest.txt", "r")
    p = pickle.load(txtFile)
    print(p)
    txtFile.close()

def readPickle():
    txtFile = open("PickleTest.txt", "rb")
    p = pickle.load(txtFile)
    print(p)
    txtFile.close()

print("Notice the error received above. This is caught by our try/except code beginning the script.\n")
userA = input("We need to store data with pickling. Press enter to do so.")
dataEntryPickle()
while(True):
    userB = input("\nWe now want to read that data. Press 1 to read in binary mode or 2 to read in regular mode and receive an error and end program.")
    if userB == "1":
        readPickle()
    elif userB == "2":
        readPickleError()
    else:
        print("Please type 1 or 2.")

